const express = require('express');
const mongoose = require('mongoose');
mongoose.set('strictQuery', true);
const router = require('./routes');
require('dotenv').config();

const app = express();
app.use(express.json());
mongoose.connect('mongodb://127.0.0.1:27017/college',
{
    useNewUrlParser: true,
    useUnifiedTopology: true
});

const db = mongoose.connection;
db.on('error', console.error.bind(console, "encountered error"));
db.once('open',() =>{
    console.log("Connected");
})

app.use(router);
app.get('/',(req, res)=>{
    res.send("HELLO");
})

app.listen(3000, ()=>{ console.log("server is running!"); });
