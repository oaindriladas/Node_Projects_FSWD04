const mongoose = require('mongoose');
const teacher = require('./teacherShema');
const express = require('express');
const app = express();

app.post('/add', async (req,res)=>{
    const teacher_obj = new teacher(req.body);
try{
    await teacher_obj.save();
    res.send(teacher_obj);
}
catch( error ){
res.status(500).send(error);
}
});

app.get('/find', async(req,res) => {
const teachers = await teacher.find({});
try{
res.send(teachers);
}
catch( error )
{
res.status(500).send(error);
}
});

app.get('/findbyid', (req,res)=>{
    const id= req.body.id;
    teacher.findById(id, (error, result)=>{
        if(error)
        console.log(error);
        else{
            console.log("Result: ", result);
            res.send(result);
        }
    })
})

module.exports = app;