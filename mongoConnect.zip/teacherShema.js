const mongoose= require('mongoose');

const teachschema = mongoose.Schema({
tname :{ type: String, required: true },
dept : { type: String, required: true },
})

const teacher = mongoose.model("teacher", teachschema);
module.exports = teacher;