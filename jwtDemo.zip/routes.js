const express = require('express');
const mongoose = require('mongoose');
const app= express();
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const user = require('./schema');
const token_key= 'abcdef';

app.get('/welcome',(req, res)=>{
    res.send("WELCOME TO AUTHENTICATION");
})

app.post('/register',async (request, response) => {

    const { username, email, password } = request.body;
    try{
if(!(username && email && password))
res.status(500).send("Please enter all fields");

const existingUser = await user.findOne({email});

if(existingUser){
    return response.send("user exists,pls login");
    }
    encrptpassword = await bcrypt.hash(password,10);

    const newUser = await user.create({
        username,
        email: email.toLowerCase(),
        password: encrptpassword,
    });
    
    const token = jwt.sign(
        { userid: newUser._id, email},
        token_key,
        {
            expiresIn: "2h",
        }
    );
    newUser.token = token;
    response.status(200).send(newUser);
}
    catch(error)
    {
console.log(error);
    }
})

app.post('/login', async (request, response)=>{
 const { email, password} = request.body;
 try{
    if(!(email && password))
    { response.status(500).send("Enter all fields"); }

    const oldUser = await user.findOne({email});

    if(oldUser && ( await bcrypt.compare(password, oldUser.password)))
    {
        const token = jwt.sign( 
            { userid: oldUser._id, email},
            token_key,
            {
                expiresIn: "2h"
            });
            oldUser.token = token;

            response.status(200).json(oldUser);
    } // end of if block
    response.status(400).send("Invalid credentials");
 }
 catch(error)
 {
    console.log(error);
 }
})

module.exports= app;