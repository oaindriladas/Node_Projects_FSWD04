const express = require('express');
const mongoose = require('mongoose');
const { route } = require('./routes');
const app= express();
const router = require('./routes');
mongoose.set('strictQuery',true);
app.use(express.json());
app.use(router);

mongoose.connect('mongodb://127.0.0.1:27017/college', {
useNewUrlParser: true,
useUnifiedTopology: true
})

const db = mongoose.connection;
db.on('error',()=>{ console.log("encountered error"); } );
db.once('open', () => {
    console.log("Connected");
})


app.listen(3000, () => {
    console.log("Server running on 3000!");
})